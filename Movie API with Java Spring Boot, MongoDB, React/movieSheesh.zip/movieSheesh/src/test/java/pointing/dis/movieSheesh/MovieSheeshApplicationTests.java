package pointing.dis.movieSheesh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieSheeshApplicationTests {

	@Test
	void contextLoads() {
	}

}
