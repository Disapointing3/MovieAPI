package pointing.dis.movieSheesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieSheeshApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieSheeshApplication.class, args);
	}

}
